
package rescatedemascota;

//juan estban moya riaño
public class RescM {

    public static void main(String[] args) {
          vista  vista  = new vista ();
          vista.setVisible(true);
        
    }
    
}
